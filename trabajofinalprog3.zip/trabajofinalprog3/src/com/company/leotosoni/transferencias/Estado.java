package com.company.leotosoni.transferencias;

import java.io.Serializable;

public enum Estado implements Serializable {
    PENDIENTE,
    APROBADA
}
