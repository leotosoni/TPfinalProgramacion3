package com.company.leotosoni.transferencias;

import com.company.leotosoni.utiles.JsonFiling;
import com.google.gson.Gson;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ListTransferencia implements JsonFiling<ListTransferencia>, Serializable {
    private static final long serialValue = 88392039029384L;
    private List<Transferencia> listaTransferencia;

    // CONSTRUCTOR
    public ListTransferencia() {
        this.listaTransferencia = new ArrayList<>();
    }

    // GETTER
    public List<Transferencia> getListaTransferencia() {return listaTransferencia;}

    // SETTER
    public void setListaTransferencia(List<Transferencia> listaTransferencia) { this.listaTransferencia = listaTransferencia;}

    // AGREGA TRANSFERENCIA A LA LISTA
    public void agregarTransferencia(Transferencia transferencia) {
        this.listaTransferencia.add(transferencia);
    }

    // ELIMINA TRANSFERENCIA DE LA LISTA
    public void eliminarTransferencia(Transferencia transferencia) {
        this.listaTransferencia.remove(transferencia);
    }


    @Override
    public ListTransferencia leerJsonFileAObjeto(String path) {
        ListTransferencia listTransferencia = new ListTransferencia();
        try {
            File file = new File(path);
            if (file.exists()) {
                Gson gson = new Gson();
                Reader reader = Files.newBufferedReader(Paths.get(path));
                listTransferencia = gson.fromJson(reader, ListTransferencia.class);
                reader.close();
                // SI LA LISTA ES NULL, RETORNA EL CONSTRUCTOR
                if(listTransferencia==null){
                    return this;
                }
            } else {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("NO SE PUEDE ABRIR EL ARCHIVO: " + e.getMessage());
        }
        return listTransferencia;
    }

    @Override
    public void escribirObjetoAJsonFile(String path) {
        try {
            Writer writer = new FileWriter(path);
            new Gson().toJson(this, writer);
            writer.close();
        } catch (IOException e) {
            System.out.println("HUBO UN ERROR AL ESCRIBIR EL ARCHIVO: " + e.getMessage());
        }
    }
}
