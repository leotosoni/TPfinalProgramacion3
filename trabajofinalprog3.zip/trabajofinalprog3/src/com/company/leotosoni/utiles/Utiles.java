package com.company.leotosoni.utiles;

import com.company.leotosoni.transferencias.Estado;
import com.company.leotosoni.transferencias.ListTransferencia;
import com.company.leotosoni.transferencias.Transferencia;
import com.company.leotosoni.usuarios.MapUsuario;
import com.company.leotosoni.usuarios.Usuario;

import java.io.IOException;
import java.time.LocalDate;
import java.util.*;


public abstract class Utiles {

    public final static String usuarioPath = "users.json";
    public final static String transferenciaPath = "transferencia.json";
    public final static String blockchainPath = "blockchain.json";

    // PANTALLA DE INICIO DEL PROGRAMA
    public static void inicioPantalla(MapUsuario mapUsuario, ListTransferencia listTransferencia, ListTransferencia listBlockchain) {
        BC();
        int option;
        do {
            System.out.println("------BIENVENIDO!!!------");
            System.out.println("1. LOGIN");
            System.out.println("2. SIGN UP");
            System.out.println("3. EXIT");

            option = validadorOpciones(1, 3);

            switch (option) {
                case 1 -> login(mapUsuario, listTransferencia, listBlockchain);
                case 2 -> registrarse(mapUsuario);
                case 3 -> hastaLuego();
            }
        } while (option != 3);
    }

    // PANTALLA DE LOGIN
    public static void login(MapUsuario mapUsuario, ListTransferencia listTransferencia, ListTransferencia listBlockchain) {
        BC();
        int intentos = 3;
        Scanner scanner = new Scanner(System.in);
        Usuario login;
        do {
            System.out.println("-------LOGIN-------");
            System.out.println("EMAIL: ");
            String email = scanner.next();
            System.out.println("CONTRASENIA: ");
            String password = scanner.next();

            // BUSCA EL USUARIO SEGUN EMAIL Y CONTRASENIA INGRESADOS
            login = mapUsuario.buscarUsuarioPorEmailandContrasenia(email, password);

            if (login != null) { // USUARIO EXISTE
                intentos = -1;
            } else { // USUARIO NO EXISTE
                System.out.println("EMAIL O CONTRASENIA INCORRECTO");
                System.out.println("INTENTELO NUEVAMENTE....");
                intentos--;
            }
        } while (intentos > 0);

        // SI EL USUARIO EXISTE, PREGUNTAMOS POR EL ID UNICO DE BILLETERA
        if (intentos == -1) {
            System.out.println("INGRESE SU ID UNICO DE BILLETERA");
            String codigo = scanner.next();
            if (codigo.compareTo(login.getUuidCodigo().toString()) == 0) {
                System.out.println("ID CORRECTO!!!");
                mainMenu(login, mapUsuario, listTransferencia, listBlockchain);
            } else {
                System.out.println("ID INCORRECTO...");
            }
        }
    }

    // PANTALLA DE REGISTRO DE USUARIO NUEVO
    public static void registrarse(MapUsuario mapUsuario) {
        BC();
        System.out.println("------SIGN UP------");

        // VALIDAMOS SI ES MAYOR DE 18 ANIOS PREGUNTAMDO EL ANIO DE NACIMIENTO
        System.out.println("INGRESE SU ANIO DE NACIMIENTO");
        int birthYear = validadorOpciones(1990, LocalDate.now().getYear(), "EL ANIO");
        int validadorEdad = LocalDate.now().getYear() - birthYear;

        if (validadorEdad >= 18) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("INGRESE SU APELLIDO");
            String apellido = scanner.nextLine();
            System.out.println("INGRESE SU NOMBRE");
            String nombre = scanner.nextLine();
            System.out.println("INGRESE SU EMAIL");
            String email = validadorEmail(mapUsuario);
            System.out.println("INGRESE UNA CONTRASENIA");
            String password = scanner.next();
            Usuario newUsuario = new Usuario(nombre, apellido, email, password, birthYear);

            System.out.println("SU ID UNICO DE BILLETERA: " + newUsuario.getUuidCodigo().toString());
            System.out.println("(GUARDE ESTE CODIGO YA QUE SE MUESTRA POR UNICA VEZ)");
            mapUsuario.agregarUsuario(newUsuario);
        } else {
            System.out.println("DEBE SER MAYOR DE 18 ANIOS PARA REGISTRARSE");
        }
        presioneTeclaParaContinuar();
    }

    // MENU PRINCIPAL DE USUARIO
    public static void mainMenu(Usuario usuario, MapUsuario mapUsuario, ListTransferencia listTransferencia, ListTransferencia listBlockchain) {
        int option;
        do {
            BC();
            System.out.println("------MAIN MENU------");
            System.out.println("1. VER LA LISTA DE USUARIOS");
            System.out.println("2. CONSULTAR EL ESTADO DE LA CUENTA");
            System.out.println("3. REALIZAR UNA TRANSFERENCIA NUEVA");
            System.out.println("4. VER TRANSFERENCIAS PENDIENTES");
            System.out.println("5. VALIDAR TRANSFERENCIAS DE TERCEROS");
            System.out.println("6. HISTORIAL DE TRANSFERENCIAS");
            System.out.println("7. SALIR");

            option = validadorOpciones(1, 7);

            switch (option) {
                case 1 -> menuListaUsuarios(usuario, mapUsuario);
                case 2 -> menuEstadoDeLACuenta(usuario);
                case 3 -> menuRealizarNuevaTransferencia(usuario, mapUsuario, listTransferencia);
                case 4 -> menuTransferenciasPendientes(usuario, mapUsuario, listTransferencia);
                case 5 -> menuTransferenciasAValidar(usuario, mapUsuario, listTransferencia, listBlockchain);
                case 6 -> menuHistorialTransferencias(usuario, mapUsuario, listBlockchain);
            }
        } while (option != 7);
    }

    // ESTE MENU MUESTRA LOS USUARIOS REGISTRADOS. EL USUARIO PUEDE CHEQUEAR LOS ID DE BILLETERA DE LOS USUARIOS A TRANSFERIR
    public static void menuListaUsuarios(Usuario usuario, MapUsuario mapUsuario) {
        System.out.println("|NOMBRE|\t|APELLIDO|\t|ID UNICO DE BILLETERA|");
        for (Usuario user : mapUsuario.getMapUsuario().values()) {
            if (!user.equals(usuario)) { // NO IMPRIME EL USUARIO LOGUEADO
                System.out.println(user.getNombre() + "\t\t"
                        + user.getApellido() + "\t\t"
                        + user.getUuidCodigo().toString());
            }
        }
        presioneTeclaParaContinuar();
    }

    // ESTE MENU MUESTRA LAS UTN COINS DISPONIBLES DEL USUARIO
    public static void menuEstadoDeLACuenta(Usuario usuario) {
        BC();
        System.out.println("ESTADO DE LA CUENTA DE " + usuario.getNombre().toUpperCase()
                + " " + usuario.getApellido().toUpperCase());
        System.out.println("USTED TIENE: " + usuario.getUtnCoins() + " UTN COINS DISPONIBLES");
        presioneTeclaParaContinuar();
    }

    // ESTE MENU PERMITE REALIZAR UNA TRANSFERENCIA NUEVA A OTRO USUARIO
    public static void menuRealizarNuevaTransferencia(Usuario usuario, MapUsuario mapUsuario, ListTransferencia listTransferencia) {
        System.out.println("INGRESE EL ID UNICO DE BILLETERA DEL USUARIO DESTINO: ");
        try {
            UUID codigo = UUID.fromString(new Scanner(System.in).nextLine());
            // LA CONDICION IF EVALUA SI EL CODIGO UUID ES IGUAL O NO AL CODIGO UUID DEL USUARIO LOGUEADO
            if (usuario.getUuidCodigo().equals(codigo)) {
                System.out.println("ID INVALIDO...");
            } else {
                // SI NO ES IGUAL, BUSCA EL USUARIO QUE TENGA EL CODIGO UUID INGRESADO
                Usuario destino = mapUsuario.buscarUsuarioPorBilletera(codigo);
                if (destino == null) {
                    System.out.println("USUARIO NO ENCONTRADO ....");
                } else {
                    // SI EL DESTINO EXISTE, MUESTRA LA INFORMACION DEL DESTINO
                    System.out.println("USUARIO ENCONTRADO!!!!");
                    System.out.println("|||| " + destino.getNombre().toUpperCase()
                            + " " + destino.getApellido().toUpperCase() + " ||||");

                    System.out.println("\nSALDO DISPONIBLE PARA TRANSFERIR: " + usuario.getUtnCoins());
                    System.out.println("INGRESE EL MONTO A TRANSFERIR: ");

                    double monto;
                    // EL CICLO DO WHILE SE USA PARA VALIDAR QUE EL MONTO A TRANSFERIR SEA MENOR AL MONTO DISPONIBLE
                    do {
                        monto = new Scanner(System.in).nextDouble();
                        if (monto > usuario.getUtnCoins()) {
                            System.out.println("EL MONTO ES SUPERIOR A SU SALDO DISPONIBLE");
                            System.out.println("INTENTE NUEVAMENTE...");
                        }
                    } while (monto > usuario.getUtnCoins());

                    System.out.println("TRANSFERENCIA DE " + monto + " UTC COINS A " + destino.getNombre().toUpperCase());
                    System.out.println("CONFIRMA LA TRANSFERENCIA?");
                    System.out.println("1. SI");
                    System.out.println("2. NO");
                    int opcion = validadorOpciones(1, 2);

                    if (opcion == 1) {
                        // INSTANCIACION DE UNA NUEVA TRANSFERENCIA
                        Transferencia nueva = new Transferencia(usuario.getUuidCodigo(), destino.getUuidCodigo(), monto);
                        // SE AGREGA LA TRANSFERENCIA A LA LISTA
                        listTransferencia.agregarTransferencia(nueva);
                        System.out.println("TRANSFERENCIA CREADA EXITOSAMENTE");
                        System.out.println("CODIGO DE LA TRANSFERENCIA: " + nueva.getUniqueID());
                        // SE MODIFICA EL SALDO DEL USUARIO SUSTRAYENDO EL MONTO QUE FUE TRANSFERIDO
                        mapUsuario.modificarUTCoinsDeUsuario(usuario.getEmail(), monto);
                    }
                }
            }
        } catch (IllegalArgumentException e) {
            // ERROR DE CASTEO DEL STRING A UUID
            System.out.println("ID INVALIDO...");
        }
        presioneTeclaParaContinuar();
    }

    // ESTE MENU PERMITE AL USUARIO VER LAS TRANSFERENCIAS HECHAS POR EL
    public static void menuTransferenciasPendientes(Usuario usuario, MapUsuario mapUsuario, ListTransferencia listTransferencia) {

        // SE FILTRAN LAS TRANSFERENCIAS QUE SOLAMENTE CONTENGAN AL USUARIO LOGUEADO COMO ORIGEN O DESTINO
        List<Transferencia> lista = new ArrayList<>(listTransferencia.getListaTransferencia());
        if (lista.isEmpty()) {
            System.out.println("---- NO HAY TRANFERENCIAS PENDIENTES ----");
        } else {
            for (Transferencia t : lista) {
                if (t.getOrigen().equals(usuario.getUuidCodigo())) {
                    Usuario destino = mapUsuario.buscarUsuarioPorBilletera(t.getDestino());
                    System.out.println("DESTINATARIO: " + destino.getNombre().toUpperCase()
                            + " " + destino.getApellido().toUpperCase()
                            + "\t MONTO: " + t.getMonto() + " UTNcoins"
                            + "\t ID: " + t.getUniqueID().toString());
                }
            }
        }
        presioneTeclaParaContinuar();
    }

    // ESTE MENU PERMITE AL USUARIO VALIDAR TRANFERENCIAS DE TERCEROS
    public static void menuTransferenciasAValidar(Usuario usuario, MapUsuario mapUsuario, ListTransferencia listTransferencia, ListTransferencia listBlockchain) {
        // CREO UNA LISTA VACIA PARA ALOJAR LAS TRANSFERENCIA DE TERCEROS
        List<Transferencia> aValidar = new ArrayList<>();

        int posicion = 1;
        for (Transferencia t : listTransferencia.getListaTransferencia()) {
            // CREO UNA LISTA DE CODIGO UUID DE TERCEROS
            List<UUID> listArray = Arrays.asList(t.getValidaciones());
            // VALIDO SI EL USUARIO ES EL ORIGEN O DESTINO DE LA TRANSFERENCIA
            if (!t.getOrigen().equals(usuario.getUuidCodigo()) && !t.getDestino().equals(usuario.getUuidCodigo())) {
                // VALIDO SI EL USUARIO YA HA VALIDO LA TRANSFERENCIA
                if (!listArray.toString().contains(usuario.getUuidCodigo().toString())) {
                    // GUARDO LAS TRANSFERENCIAS VALIDADAS EN LA LISTA VACIA
                    aValidar.add(t);
                    Usuario origen = mapUsuario.buscarUsuarioPorBilletera(t.getOrigen());
                    Usuario destino = mapUsuario.buscarUsuarioPorBilletera(t.getDestino());
                    System.out.println(posicion + ". " + origen.getNombre().toUpperCase() + " --> "
                            + destino.getNombre().toUpperCase()
                            + ": " + t.getMonto() + " UTNcoins");
                    posicion++;
                }
            }
        }
        if (!aValidar.isEmpty()) {
            System.out.println("DESEA VALIDAR ALGUNA TRANSACCION?");
            System.out.println("1. SI");
            System.out.println("2. NO");

            int resp = validadorOpciones(1, 2);
            if (resp == 1) {
                System.out.println("ELIJA UNA TRANSFERENCIA DE TERCEROS A VALIDAR");
                int opcion = validadorOpciones(1, aValidar.size());
                // ELIJO LA TRANSFERENCIA A VALIDAR INGRESANDO LA POSICION
                Transferencia elegida = aValidar.get(opcion - 1);
                // ELIMINO LA TRANSFERENCIA ELEGIDA DE LA LISTA listTransferencia
                listTransferencia.eliminarTransferencia(elegida);
                // AGREGO AL USUARIO AL ARREGLO DE USUARIOS DE LA TRANSFERENCIA ELEGIDA
                elegida.agregarUsuario(usuario.getUuidCodigo());

                // LA SENTENCIA IF VALIDA SI LA TRANSFERENCIA HA SIDO VALIDADA POR MENOS DE 3 USUARIOS.
                if (elegida.getContador() < 3) {
                    // VUELVE A AGREGAR LA TRANSFERENCIA A LA LISTA listTransferencia
                    listTransferencia.agregarTransferencia(elegida);
                } else {
                    // LA TRANSFERENCIA CAMBIA DE "PENDIENTE" A "APROBADA" Y SE AGREGA AL BLOCKCHAIN
                    elegida.setEstado(Estado.APROBADA);
                    listBlockchain.agregarTransferencia(elegida);
                    Usuario destino = mapUsuario.buscarUsuarioPorBilletera(elegida.getDestino());
                    // FINALMENTE LOS FONDOS SON AGREGADOS AL USUARIO DESTINO
                    mapUsuario.modificarUTCoinsDeUsuario(destino.getEmail(), elegida.getMonto() * (-1));
                }
                System.out.println("VALIDACION EXITOSA!!!!!!");
            }
        } else {
            System.out.println("NO HAY TRANSFERENCIAS POR VALIDAR....");
        }
        presioneTeclaParaContinuar();
    }

    public static void menuHistorialTransferencias(Usuario usuario, MapUsuario mapUsuario, ListTransferencia listBlockchain) {
        // CREO UNA LISTA VACIA PARA ALOJAR LAS TRANSFERENCIAS APROBADAS PROPIAS DEL USUARIO
        List<Transferencia> blockchainPorUsuario = new ArrayList<>();

        // RECORRE LA LISTA DE TRANSFERENCIA Y AGREGO A LA LISTA VACIA LAS TRANSFERENCIAS DONDE EL USUARIO SEA ORIGEN O DESTINO
        for (Transferencia t : listBlockchain.getListaTransferencia()) {
            if (t.getOrigen().equals(usuario.getUuidCodigo())
                    || t.getDestino().equals(usuario.getUuidCodigo())) {
                blockchainPorUsuario.add(t);
            }
        }
        if (blockchainPorUsuario.isEmpty()) {
            System.out.println(".....HISTORIAL VACIO.....");
        } else {
            Usuario origen;
            Usuario destino;
            for (Transferencia tr : blockchainPorUsuario) {
                if (tr.getOrigen().equals(usuario.getUuidCodigo())) {
                    origen = usuario;
                    destino = mapUsuario.buscarUsuarioPorBilletera(tr.getDestino());
                } else {
                    origen = mapUsuario.buscarUsuarioPorBilletera(tr.getOrigen());
                    destino = usuario;
                }
                System.out.println(origen.getNombre().toUpperCase() + " " + origen.getApellido().toUpperCase() + " ----> "
                        + destino.getNombre().toUpperCase() + " " + destino.getApellido().toUpperCase()
                        + "\t MONTO: " + tr.getMonto() + " UTN COINS"
                        + "\t ID TRANSFERENCIA: " + tr.getUniqueID().toString());

            }

        }
        presioneTeclaParaContinuar();
    }

    public static void presioneTeclaParaContinuar() {
        System.out.println("PRESIONE ENTER PARA CONTINUAR");
        try {
            System.in.read();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void BC() {
        System.out.println("|||||||| ■   ■  ■■■■■  ■■    ■     ■■■■■      ■■■■■ ||||||||");
        System.out.println("|||||||| ■   ■    ■    ■ ■   ■     ■    ■    ■■     ||||||||");
        System.out.println("|||||||| ■   ■    ■    ■  ■  ■     ■■■■      ■      ||||||||");
        System.out.println("|||||||| ■   ■    ■    ■   ■ ■     ■    ■    ■■     ||||||||");
        System.out.println("||||||||  ■■■     ■    ■    ■■     ■■■■■      ■■■■■ ||||||||");
    }

    public static void hastaLuego() {
        System.out.println("\n\n\t\t----- HASTA LA PROXIMA ..... -----");

    }

    // VALIDADOR DE OPCIONES TIPO INT INGRESADAS POR TECLADO
    public static int validadorOpciones(int min, int max) {
        int opcion = 0;
        int flag;

        Scanner scanner = new Scanner(System.in);
        do {
            do {
                try {
                    System.out.println("INGRESE UNA OPCION");
                    opcion = Integer.parseInt(scanner.next());
                    flag = 0;
                } catch (NumberFormatException e) {
                    System.out.println("HA INGRESADO UNA OPCION INVALIDA. INTENTE NUEVAMENTE");
                    flag = 1;
                }
            } while (flag == 1);

            if (opcion < min || opcion > max) {
                System.out.println("HA INGRESADO UNA OPCION INCORRECTA. INTENTE NUEVAMENTE");
                flag = 1;
            }
        } while (flag == 1);

        return opcion;
    }

    // VALIDADOR DE OPCIONES TIPO INT INGRESADAS POR TECLADO
    public static int validadorOpciones(int min, int max, String text) {
        int opcion = 0;
        int flag;

        Scanner scanner = new Scanner(System.in);
        do {
            do {
                try {
                    opcion = Integer.parseInt(scanner.next());
                    flag = 0;
                } catch (NumberFormatException e) {
                    System.out.println("ERROR AL INGRESAR " + text + ". INTENTE NUEVAMENTE");
                    flag = 1;
                }
            } while (flag == 1);

            if (opcion < min || opcion > max) {
                System.out.println("ERROR AL INGRESAR " + text + ". INTENTE NUEVAMENTE");
                flag = 1;
            }
        } while (flag == 1);

        return opcion;
    }

    /// VALIDADOR DE EMAIL. EL EMAIL ES VALIDO SI CONTIENE '@' o '.'. TAMBIEN CHEQUEA QUE EL EMAIL NO SE INGRESE DOS VECES
    public static String validadorEmail(MapUsuario mapUsuario) {
        Scanner scanner = new Scanner(System.in);
        String email = scanner.nextLine();
        while (!email.contains("@") || !email.contains(".") || mapUsuario.usuarioExiste(email)) {
            if (!email.contains("@") || !email.contains(".")) {
                System.out.println("EMAIL INGRESADO NO VALIDO");
            } else if (mapUsuario.usuarioExiste(email)) {
                System.out.println("YA EXISTE UN USUARIO REGISTRADO CON ESTA DIRECCION DE EMAIL");
            }
            System.out.println("INTENTE NUEVAMENTE");
            email = scanner.nextLine();
        }
        return email;
    }

}
