package com.company.leotosoni.utiles;

// INTERFACE CON METODOS PARA LA LECTURA Y ESCRITURA DE ARCHIVOS JSON

public interface JsonFiling<T> {
    T leerJsonFileAObjeto(String path);
    void escribirObjetoAJsonFile(String path);
}
