package com.company.leotosoni.usuarios;

import com.company.leotosoni.utiles.JsonFiling;
import com.google.gson.Gson;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class MapUsuario implements JsonFiling<MapUsuario>, Serializable {

    private static final long serialValue = 88392039029384L;
    private HashMap<String, Usuario> mapUsuario;

    // CONSTRUCTOR
    public MapUsuario() {
        this.mapUsuario = new HashMap<>();
    }

    // GETTER
    public HashMap<String, Usuario> getMapUsuario() {
        return this.mapUsuario;
    }

    // SETTER
    public void setMapUsuario(HashMap<String, Usuario> mapaUsuario) {
        this.mapUsuario = mapaUsuario;
    }

    // AGREGAR UN USUARIO NUEVO AL HASHMAP
    public void agregarUsuario(Usuario nuevo) {
        this.mapUsuario.put(nuevo.getEmail(), nuevo);
    }

    // DEVUELVE TRUE SI USUARIO EXISTE DADO EMAIL
    public boolean usuarioExiste(String email) {
        return this.mapUsuario.containsKey(email);
    }

    // DEVUELVE USUARIO DADO EMAIL. SI EMAIL NO EXISTE, DEVUELVE NULL
    public Usuario obtenerUsuarioPorEmail(String email) {
        return this.getMapUsuario().get(email);
    }

    // BUSCA USUARIO POR EMAIL. SI LA CONTRASENIA COINCIDE, DEVUELVE USUARIO. SINO DEVUELVE NULL
    public Usuario buscarUsuarioPorEmailandContrasenia(String email, String contrasenia) {
        Usuario usuario = null;
        if (usuarioExiste(email)) {
            usuario = obtenerUsuarioPorEmail(email);
            if (!usuario.getPassword().equals(contrasenia)) {
                usuario = null;
            }
        }
        return usuario;
    }

    // MODIFICA EL VALOR DE LAS UTN COINS. REEMPLAZA EL USUARIO EN EL HASHMAP
    public void modificarUTCoinsDeUsuario(String email, double monto) {
        Usuario usuario = this.getMapUsuario().get(email);
        usuario.setUtnCoins(usuario.getUtnCoins() - monto);
        this.mapUsuario.replace(email, usuario);

    }

    /// BUSCA USUARIO POR ID DE BILLETERA. SI UUID CODIGO EXISTE
    public Usuario buscarUsuarioPorBilletera(UUID codigo) {
        Usuario encontrado = null;
        // CREACION DE UN ITERATOR
        Iterator<Map.Entry<String, Usuario>> iterator = this.getMapUsuario().entrySet().iterator();

        // CICLO WHILE QUE RECORRE EL ITERATOR HASTA ENCONTRE EL USUARIO CON EL MISMO UUID CODIGO
        while (iterator.hasNext() && encontrado == null) {
            Map.Entry<String, Usuario> entry = iterator.next();
            Usuario current = entry.getValue();
            if (current.getUuidCodigo().equals(codigo)) {
                encontrado = current;
                break;
            }
        }
        return encontrado;
    }

    @Override
    public MapUsuario leerJsonFileAObjeto(String path) {
        MapUsuario map = new MapUsuario();
        try {
            File file = new File(path);
            if (file.exists()) {
                Gson gson = new Gson();
                Reader reader = Files.newBufferedReader(Paths.get(path));
                map = gson.fromJson(reader, MapUsuario.class);
                reader.close();
                // SI LA LISTA ES NULL, RETORNA EL CONSTRUCTOR
                if(mapUsuario==null){
                    return this;
                }
            } else {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("NO SE PUEDE ABRIR EL ARCHIVO: " + e.getMessage());
        }
        return map;
    }

    @Override
    public void escribirObjetoAJsonFile(String path) {
        try {
            Writer writer = new FileWriter(path);
            new Gson().toJson(this, writer);
            writer.close();
        } catch (IOException e) {
            System.out.println("HUBO UN ERROR AL ESCRIBIR EL ARCHIVO: " + e.getMessage());
        }
    }
}
