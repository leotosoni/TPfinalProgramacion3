package com.company.leotosoni.usuarios;

import java.io.Serializable;
import java.util.UUID;

public class Usuario implements Serializable {

    private static final long serialValue = 88392039029384L;
    private String nombre;
    private String apellido;
    private String email;
    private String password;
    private int birthYear;
    private UUID uuidCodigo;
    private double utnCoins = 100.0;

    //CONSTRUCTOR VACIO
    public Usuario() {
    }

    // CONSTRUCTOR CON PARAMETROS
    public Usuario(String nombre, String apellido, String email, String password, int birthYear) {
        this();
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.password = password;
        this.birthYear = birthYear;
        this.uuidCodigo = UUID.randomUUID();
    }

    // GETTERS AND SETTERS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String userName) {
        this.email = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    public UUID getUuidCodigo() {
        return uuidCodigo;
    }

    public void setUuidCodigo(UUID uuidCodigo) {
        this.uuidCodigo = uuidCodigo;
    }

    public double getUtnCoins() {
        return utnCoins;
    }

    public void setUtnCoins(double utnCoins) {
        this.utnCoins = utnCoins;
    }


}
