package com.company.leotosoni.blockchain;

import com.company.leotosoni.transferencias.ListTransferencia;
import com.company.leotosoni.usuarios.MapUsuario;

import static com.company.leotosoni.utiles.Utiles.*;

public class Main {

    public static void main(String[] args) {
        // LECTURA DE LOS USUARIOS DESDE ARCHIVO JSON
        MapUsuario mapUsuario = new MapUsuario().leerJsonFileAObjeto(usuarioPath);
        // LECTURA DE LOS TRANSFERENCIAS DESDE ARCHIVO JSON
        ListTransferencia listTransferencia = new ListTransferencia().leerJsonFileAObjeto(transferenciaPath);
        // LECTURA DEL BLOCKCHAIN DESDE ARCHIVO JSON
        ListTransferencia listBlockchain = new ListTransferencia().leerJsonFileAObjeto(blockchainPath);

        // INICIO DEL PROGRAMA
        inicioPantalla(mapUsuario, listTransferencia, listBlockchain);


        // ESCRITURA DE LOS USUARIOS EN ARCHIVO JSON
        mapUsuario.escribirObjetoAJsonFile(usuarioPath);
        // ESCRITURA DE LAS TRANSFERENCIAS EN ARCHIVO JSON
        listTransferencia.escribirObjetoAJsonFile(transferenciaPath);
        // ESCRITURA DEL BLOCKCHAIN EN ARCHIVO JSON
        listBlockchain.escribirObjetoAJsonFile(blockchainPath);

    }
}
